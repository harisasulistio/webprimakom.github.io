<?php $__env->startSection('content'); ?>
<style type="text/css">
    .section.section-grey {
    background: #ffffff;
}
</style>
<section class="section is-sm section-about">
    <div class="container">
        <h2 class="section-title mt-3" data-aos="fade-up" data-aos-delay="200">Security Solution Service<span class="text-primary">. </span></h2>

        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-4">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/flip.jpg')); ?>" alt="">
            </div>
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">Flap Barrier<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Gerbang keamanan otomatis yang dapat digunakan dalam area publik dan area terbatas untuk mempermudah pengamanan terhadap suatu area dalam menyeleksi lalu lintas orang keluar masuk sesuai dengan parameter yang diberlakukan oleh perusahaan.</p>
                    <p class="section-desc">Integrasi Data menggunakan database melalui RFID, barcode, sidik jari, ataupun wajah lain sesuai dengan kebutuhan yang digunakan sebagai media filter pengamanan.</p>
                </div>
            </div>
		</div>
		<hr class="mt-5"/>
        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">Gate Automation<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Gerbang kemanan otomatis yang digunakan dalam area publik dan area terbatas untuk mempermudah lalu lintas orang maupun kendaraan.</p>
                    <p class="section-desc">Umumnya layanan ini digunakan tanpa perlu di integrasikan dengan database aplikasi sehingga parameter untuk keamanan dapat dikombinasikan dengan filter manual dengan tombol atau dengan otomatis melalui media sensor.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/gate.jpg')); ?>" alt="">
            </div>
		</div>
		<hr class="mt-5"/>
		<div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-4">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/fiber.png')); ?>" alt="">
            </div>
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">Fiber Optic<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan transmisi pengiriman data berkecapatan tinggi melalui media optik. Optik merupakan media dengan tingkat kecepatan cahaya sehingga mendukung untuk kebutuhan penyaluran data dengan cepat dalam jumlah besar.</p>
                    <p class="section-desc">Pengiriman data yang besar, reliable, dan minim perawatan sangat membantu perusahaan untuk investasi jangka panjang sehingga dapat memberikan dampak positif terhadap budgeting perusahaan terhadap Infrastruktur IT.</p>
                </div>
            </div>
		</div>
		<hr class="mt-5"/>
        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-8">
				<div class="section-head">
					<h2 class="section-title">CCTV Industrial<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan pengamanan monitoring melalui media CCTV (Closed Circuit Television) dimana medianya berupa kamera yang dipasang di beberapa area yang menjadi titik keamanan.</p>
                    <p class="section-desc">Layanan ini dapat diterapkan untuk memonitor produktivitas karyawan maupun keamanan barang sehingga meminimalisir kekhawatiran terhadap produktivitas karyawan dan keamanan logistik di perusahaan.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/cctv.png')); ?>" alt="">
            </div>
		</div>
		<hr class="mt-5"/>
		<div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-4">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/rfid.png')); ?>" alt="">
            </div>
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">RFID People Tracking<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan keamanan dengan RFID (Radio Frequency ID) dimana medianya dapat berupa kartu dan berfungsi untuk memonitor karyawan dalam kepentingan pengawasan terhadap area terbatas maupun untuk memonitor sistem absensi dan lembur karyawan.</p>
                </div>
            </div>
		</div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webprimakom\webprimakom\resources\views/products/security_solution.blade.php ENDPATH**/ ?>