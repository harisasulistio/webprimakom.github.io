<?php $__env->startSection('content'); ?>
<style type="text/css">
    .section.section-grey {
    background: #ffffff;
}
</style>
<section class="section is-sm section-about">
    <div class="container">
        

        <div class="row flex vcenter pt-5 mt-5">
            <div class="col-lg-8" data-aos="fade-left" data-aos-delay="200">
				<div class="section-head">
					<h2 class="section-title">Prima Meet<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan Meeting melalui virtual yang diberikan secara gratis kepada pelanggan PT Prima Mandiri Komunikasi didalam upaya meningkatkan koordinasi dan efektif untuk menekan waktu koordinasi.</p>
                </div>
			</div>
			<div class="col-lg-4" data-aos="fade-left" data-aos-delay="300">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/primameet.png')); ?>" alt="">
            </div>
		</div>

		<div class="row flex vcenter justify-content-center pt-5 mt-5">
            <div class="col-12">
				<div class="section-head" data-aos="fade-up" data-aos-delay="200">
					<h2 class="section-title"> Keunggulan Prima Meet<span class="text-primary">. </span></h2>
				</div>
                
			</div>
			<div class="col-lg-8" data-aos="fade-up" data-aos-delay="300">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/keunggulan_primameet.jpg')); ?>" alt="">
            </div>
		</div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webprimakom\webprimakom\resources\views/products/prima_meet.blade.php ENDPATH**/ ?>