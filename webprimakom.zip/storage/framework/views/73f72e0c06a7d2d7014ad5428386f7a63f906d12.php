<?php $__env->startSection('content'); ?>
<style type="text/css">
    .section.section-grey {
    background: #ffffff;
}
</style>
<section class="section is-sm section-about">
    <div class="container">
        <h2 class="section-title mt-3" data-aos="fade-up" data-aos-delay="200">IT Infrastructure<span class="text-primary">. </span></h2>

        <div class="row flex vcenter pt-5 mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-6">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/kubernetes.jpg')); ?>" alt="">
            </div>
            <div class="col-lg-6 p-5">
				<div class="section-head">
					<h2 class="section-title">Kubernetes<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Platform yang digunakan untuk manajemen container base dan clusterisasi dengan tujuan untuk meminimalisir downtime dalam upaya memberikan teknologi yang lebih mudah dikelola, aman, sekaligus reliable.</p>
                </div>
            </div>
		</div>
		<hr class="mt-5"/>
        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-7 p-5">
				<div class="section-head">
					<h2 class="section-title">Object Storage<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Penyimpanan berbasis objek dimana dalam penyimpanannya tidak dibagi dalam blok melainkan menjadi sebuah objek yang berisi data, metadata dan indetifier unik.Dapat dikatakan ini merupakan sebuah syarat perusahaan untuk bertransformasi terhadap pertumbuhan data.</p>
                </div>
            </div>
            <div class="col-lg-5">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/object.png')); ?>" alt="">
            </div>
		</div>
		<hr class="mt-5"/>
		<div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-3">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/network.png')); ?>" alt="">
            </div>
            <div class="col-lg-9 p-5">
				<div class="section-head">
					<h2 class="section-title">Network Reengineering<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan di bidang audit networking dimana dalam prosesnya akan dilakukan assesment terhadap jaringan existing untuk dilakukan pemutakhiran terhadap sistem jaringan yang sedang berjalan untuk mendapatkan jaringan yang lebih handal, aman dan mudah untuk dimonitoring.</p>
                </div>
            </div>
		</div>
		<hr class="mt-5"/>
        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-6 p-5">
				<div class="section-head">
					<h2 class="section-title">Wifi Revolution<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Revolusi Wifi yang memanfaatkan konsep big data untuk memonetisasi dan sarana periklanan yang biasa digunakan di area pubik.</p>
                </div>
            </div>
            <div class="col-lg-6">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/wifi.png')); ?>" alt="">
            </div>
		</div>
		<hr class="mt-5"/>
		<div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-4">
                <img class="about-img" src="<?php echo e(URL::to('/assets_web/produk/troubleshoot.png')); ?>" alt="">
            </div>
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">Instalasi & Troubleshooting <br/>Radio Link<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Rangkaian jaringan yang digunakan untuk komunikasi wireless dengan memanfaatkan gelombang elektromagnetik untuk mengirimkan sinyal jarak jauh.</p>
                </div>
            </div>
		</div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webprimakom\webprimakom\resources\views/products/it_infrastructure.blade.php ENDPATH**/ ?>