<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(URL::to('assets_web/logo/logo_black.png')); ?>" type="image/x-icon">
    <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
    <!-- ========================================= Css files -->
    <?php echo Html::style('assets/css/bootstrap.min.css'); ?>

    <?php echo Html::style('assets/css/owl.carousel.min.css'); ?>

    <?php echo Html::style('assets/css/owl.theme.default.min.html'); ?>

    <?php echo Html::style('assets/css/slick.css'); ?>

    <?php echo Html::style('assets/css/slick-theme.css'); ?>

    <?php echo Html::style('assets/css/aos.css'); ?>

    <?php echo Html::style('assets/css/all.min.css'); ?>

    <?php echo Html::style('assets/css/style.css'); ?>

	<?php echo Html::style('assets/css/elementor.css'); ?>

    <title><?php if(isset($pageName)) { echo $pageName; } ?></title>
    <style>
    @font-face {
        font-family: 'myFirstFont';
        src: url('https://primakom.co.id/assets/fonts/FontsFree-Net-SFProText-Semibold.ttf');
        }
    @font-face {
        font-family: 'SecondFont';
        src: url('https://primakom.co.id/assets/fonts/FontsFree-Net-SFProText-Regular.ttf');
    }
    a,p,h1,h2,h3,h4,h5{
        font-family: 'SecondFont';
    }
    * {
        font-family: 'SecondFont';
    }
    .container {
        max-width: 1350px;
    }
    .kotak1{
        border-radius: 10px 10px 10px 10px;
    }
    .img_bundar{
        border-radius: 150px;
        width:200px;
    }
    .navbar .logo {
        height: 6rem;
    }
    .elementor-element.elementor-element-470b758:not(.elementor-motion-effects-element-type-background), .elementor-8803 .elementor-element.elementor-element-470b758 > .elementor-motion-effects-container > .elementor-motion-effects-layer > .elementor-shape-fill {
        background: linear-gradient(45deg, #462377, #e62c91);
        fill:#ffffff;
    }
	.logo_footer{
		width:150px;
		height: 100% !important;
	}
    </style>
</head>

<body style="overflow-x: hidden !important;">
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo Html::script('assets/js/plugins/jQuery.min.js'); ?>

    <?php echo Html::script('assets/js/plugins/modernizr.min.js'); ?>

    <?php echo Html::script('assets/js/plugins/bootstrap.min.js'); ?>

    <?php echo Html::script('assets/js/plugins/feather-icons.js'); ?>

    <?php echo Html::script('assets/js/plugins/slick.min.js'); ?>

    <?php echo Html::script('assets/js/plugins/owl.carousel.min.js'); ?>

    <?php echo Html::script('assets/js/plugins/aos.js'); ?>

    <?php echo Html::script('assets/js/plugins/typed.js'); ?>

    <?php echo Html::script('assets/js/plugins/all.min.js'); ?>

    <?php echo Html::script('assets/js/plugins/jquery.waypoints.min.js'); ?>

    <?php echo Html::script('assets/js/plugins/jquery.counterup.min.js'); ?>

    <?php echo Html::script('assets/js/main.js'); ?>

</body>
</html><?php /**PATH /usr/share/nginx/html/webprimakom/resources/views/welcome.blade.php ENDPATH**/ ?>