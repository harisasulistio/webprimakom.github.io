<?php $__env->startSection('content'); ?>

<section class="section is-sm section-about">
    <div class="container">
        <h2 class="section-title" data-aos="fade-up" data-aos-delay="100"> Company Profile </h2>
        <div class="row flex vcenter mt-2">
            <div class="col-lg-6" data-aos="fade-right" data-aos-delay="300">
                <img class="about-img kotak7" src="<?php echo e(URL::to('/assets_web/Gambar/2.jpg')); ?>" alt="">
            </div>
            <div class="col-lg-6" data-aos="fade-left" data-aos-delay="300">
                <div class="section-head">
                    <h2 class="section-title ">PT Prima Mandiri Komunikasi </h2>
                    <p class="section-desc">Didirikan pada 13 September 2016, PT. Prima Mandiri Komunikasi merupakan perusahaan yang bergerak dalam bidang ICT dan berkomitmen terhadap kualitas kerja yang maksimal untuk mencapai kepuasan pelanggan secara berkesinambungan.</p>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<section class="section is-sm section-testimonial overflow-hidden" style="padding-top:0px">
	<div class="container" style="max-width:1140px">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="section-head mb-lg-0">
					<h5 class="section-subtitle text-blue "  data-aos="fade-up" data-aos-delay="300">Insight</h5>
					<h2 class="section-title"  data-aos="fade-up" data-aos-delay="400">Our Vision<span class="text-primary">. </span></h2>
					<p class="section-desc mb-lg-0" data-aos="fade-up" data-aos-delay="400">
					To Become an Impactful Tech Company through New Breakthrough Innovation in Human Unified Communications and Interaction with Technology
					</p>
					<h2 class="section-title mt-5" data-aos="fade-up" data-aos-delay="500">Our Mision<span class="text-primary">. </span></h2>
					<p class="section-desc mb-lg-0" data-aos="fade-up" data-aos-delay="500">
					Mission We Help Companies Transform Their Business by Providing Excellent Digital Software, Hardware, and ICT Services
					</p>
				</div>
			</div>
			<div class="col-lg-6" data-aos="fade-right" data-aos-delay="300">
				<div class="client-wrap">

						<img class="img_bundar" src="<?php echo e(URL::to('/assets_web/Foto/IMG_6385.JPG')); ?>" alt="">
					<br/>
					<p class="client-quote"> Share your beautiful travel stories with bold imagery in this
						contemporary personal magazine. Featured images use the new shape dividers for extra style.
					</p>
					<div class="flex">
						<strong class=" client-name ">Ariya Totar</strong>
						<p class="client-position">CEO</p>
					</div>
				</div>
				<img class="section-shape2" src="../assets/images/bg/testimonials-bg-grad.png" alt="">
			</div>
		</div>
	</div>
</section>

<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<script type="text/javascript">
function tmpteam(idx)
{
    var request = $.ajax ({
       url : "<?php echo e(URL::to('/lihat-team-perdivisi')); ?>",
       data:"id_team="+idx,
       type : "get",
       dataType: "html"
   });
   $('#hasil').html('Sedang Melakukan Proses Pencarian Data...');
   request.done(function(output) {
       $('#hasil').html(output);
   });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webprimakom\webprimakom\resources\views/about/profile.blade.php ENDPATH**/ ?>