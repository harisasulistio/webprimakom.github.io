<?php $__env->startSection('content'); ?>
<style type="text/css">
    .section.section-grey {
    background: #ffffff;
}
</style>
<section class="section is-sm section-about">
    <div class="container">
        <h2 class="section-title" data-aos="fade-up" data-aos-delay="200">Prima Village<span class="text-primary">. </span></h2>

        <div class="row flex vcenter justify-content-center mt-5">
			<div class="col-2" data-aos="fade-right" data-aos-delay="300">
                <img class="img-fluid" src="<?php echo e(URL::to('/assets_web/produk/smartvillage.jpg')); ?>" alt="">
			</div>
			<div class="col-6" data-aos="fade-left" data-aos-delay="300">
                <img class="img-fluid" src="<?php echo e(URL::to('/assets_web/produk/keunggulan_smartvillage.jpg')); ?>" alt="">
            </div>
			<div class="col-lg-12">
				
                <div class="section-body" data-aos="fade-up" data-aos-delay="200">
                    <p class="section-desc">Platform yang digunakan untuk mempermudah masyarakat desa dalam menghadapi revolusi 4.0 dan	pengelolaan	keuangan	masyarakat desa</p>
                </div>
            </div>
		</div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webprimakom\webprimakom\resources\views/products/smart_village.blade.php ENDPATH**/ ?>