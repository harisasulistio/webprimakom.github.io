@extends('layout2')
@section('content')
<style type="text/css">
    .section.section-grey {
    background: #ffffff;
}
</style>
<section class="section is-sm section-about">
    <div class="container">
        <h2 class="section-title mt-3" data-aos="fade-up" data-aos-delay="200">Security Solution Service<span class="text-primary">. </span></h2>

        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-4">
                <img class="about-img" src="{{URL::to('/assets_web/produk/flip.jpg')}}" alt="">
            </div>
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">Flap Barrier<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Gerbang keamanan otomatis yang dapat digunakan dalam area publik dan area terbatas untuk mempermudah pengamanan terhadap suatu area dalam menyeleksi lalu lintas orang keluar masuk sesuai dengan parameter yang diberlakukan oleh perusahaan.</p>
                    <p class="section-desc">Integrasi Data menggunakan database melalui RFID, barcode, sidik jari, ataupun wajah lain sesuai dengan kebutuhan yang digunakan sebagai media filter pengamanan.</p>
                </div>
            </div>
		</div>
		<hr class="mt-5"/>
        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">Gate Automation<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Gerbang kemanan otomatis yang digunakan dalam area publik dan area terbatas untuk mempermudah lalu lintas orang maupun kendaraan.</p>
                    <p class="section-desc">Umumnya layanan ini digunakan tanpa perlu di integrasikan dengan database aplikasi sehingga parameter untuk keamanan dapat dikombinasikan dengan filter manual dengan tombol atau dengan otomatis melalui media sensor.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <img class="about-img" src="{{URL::to('/assets_web/produk/gate.jpg')}}" alt="">
            </div>
		</div>
		<hr class="mt-5"/>
		<div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-4">
                <img class="about-img" src="{{URL::to('/assets_web/produk/fiber.png')}}" alt="">
            </div>
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">Fiber Optic<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan transmisi pengiriman data berkecapatan tinggi melalui media optik. Optik merupakan media dengan tingkat kecepatan cahaya sehingga mendukung untuk kebutuhan penyaluran data dengan cepat dalam jumlah besar.</p>
                    <p class="section-desc">Pengiriman data yang besar, reliable, dan minim perawatan sangat membantu perusahaan untuk investasi jangka panjang sehingga dapat memberikan dampak positif terhadap budgeting perusahaan terhadap Infrastruktur IT.</p>
                </div>
            </div>
		</div>
		<hr class="mt-5"/>
        <div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-8">
				<div class="section-head">
					<h2 class="section-title">CCTV Industrial<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan pengamanan monitoring melalui media CCTV (Closed Circuit Television) dimana medianya berupa kamera yang dipasang di beberapa area yang menjadi titik keamanan.</p>
                    <p class="section-desc">Layanan ini dapat diterapkan untuk memonitor produktivitas karyawan maupun keamanan barang sehingga meminimalisir kekhawatiran terhadap produktivitas karyawan dan keamanan logistik di perusahaan.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <img class="about-img" src="{{URL::to('/assets_web/produk/cctv.png')}}" alt="">
            </div>
		</div>
		<hr class="mt-5"/>
		<div class="row flex vcenter mt-5" data-aos="fade-up" data-aos-delay="300">
            <div class="col-lg-4">
                <img class="about-img" src="{{URL::to('/assets_web/produk/rfid.png')}}" alt="">
            </div>
            <div class="col-lg-8 p-5">
				<div class="section-head">
					<h2 class="section-title">RFID People Tracking<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan keamanan dengan RFID (Radio Frequency ID) dimana medianya dapat berupa kartu dan berfungsi untuk memonitor karyawan dalam kepentingan pengawasan terhadap area terbatas maupun untuk memonitor sistem absensi dan lembur karyawan.</p>
                </div>
            </div>
		</div>
    </div>
</section>

{{--<section class="section is-sm section-grey">
        <div class="container">
            <div class="lines">
                <img src="../assets/images/others/lines.svg" alt="">
            </div>
            <div class="section-head flex between vcenter wrap">
                <h2 class="section-title ">Primakom Office Location<hr/></h2>
            </div>
            <div class="boxes">
                <div class="row min-30">
                    <div class="col-lg-4 col-md-6">
                        <div class="box has-secondary-bg has-left-icon">
                            <div class="box-particles2">
                                <img src="../assets/images/others/box-particle-2.svg" alt="">
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="box-icon">
                                        <ion-icon name="compass"></ion-icon>
                                    </div>
                                </div>
                                <div class="col">
                                    <h3 class="box-title"> Kantor Pusat<hr style="border: 1px solid white;"></h3>
                                    <p class="box-desc">Jalan Jombang Raya Ruko Emerald Boulevard
                                            Office Park Blok AA 2 No. 52, Pondok Aren,
                                            Kota Tangerang Selatan
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="box has-shadow has-left-icon">
                            <div class="box-particles2">
                                <img src="../assets/images/others/box-particle-2.svg" alt="">
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="box-icon">
                                        <ion-icon name="cog"></ion-icon>
                                    </div>
                                </div>
                                <div class="col">
                                    <h3 class="box-title">Kantor Pusat Operasional<hr style="border: 1px solid black;"></h3>
                                    <p class="box-desc">Jalan Jajar Tunggal Utara I Blok D 12A,
                                        Surabaya, Jawa Timur<br/><br/>
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="box has-secondary-bg has-left-icon">
                            <div class="box-particles2">
                                <img src="../assets/images/others/box-particle-2.svg" alt="">
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="box-icon">
                                        <ion-icon name="brush"></ion-icon>
                                    </div>
                                </div>
                                <div class="col">
                                    <h3 class="box-title"> Kantor Cabang Malang<hr style="border: 1px solid white;"></h3>
                                    <p class="box-desc">Jalan Notojoyo / Sunimbar Blok D, No. 51,Tegal Gondo, Kabupaten Malang<br/><br/>
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="box has-shadow has-left-icon">
                            <div class="box-particles2">
                                <img src="../assets/images/others/box-particle-2.svg" alt="">
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="box-icon">
                                        <ion-icon name="planet"></ion-icon>
                                    </div>
                                </div>
                                <div class="col">
                                    <h3 class="box-title"> Kantor Cabang Jember<hr style="border: 1px solid black;"></h3>
                                    <p class="box-desc">Jalan Semeru Raya No. D-1 Kelurahan Sumbersari, Kecamatan Sumbersari,Jember 68121</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="box has-secondary-bg has-left-icon">
                            <div class="box-particles2">
                                <img src="../assets/images/others/box-particle-2.svg" alt="">
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="box-icon">
                                        <ion-icon name="logo-slack"></ion-icon>
                                    </div>
                                </div>
                                <div class="col">
                                    <h3 class="box-title"> Kantor Cabang Denpasar <hr style="border: 1px solid white;"></h3>
                                    <p class="box-desc">Jalan Tukad Badung 20 C, Denpasar Selatan,Denpasar<br/><br/>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="box has-shadow has-left-icon">
                            <div class="box-particles2">
                                <img src="../assets/images/others/box-particle-2.svg" alt="">
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="box-icon">
                                        <ion-icon name="archive"></ion-icon>
                                    </div>
                                </div>
                                <div class="col">
                                    <h3 class="box-title"> Kantor Cabang Mataram <hr style="border: 1px solid black;"></h3>
                                    <p class="box-desc">Komplek perumahan pagutan ragency, tahap V No. 7, Mataram Pagutan<br/><br/>  </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">

                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="box has-shadow has-left-icon">
                            <div class="box-particles2">
                                <img src="../assets/images/others/box-particle-2.svg" alt="">
                            </div>
                            <div class="row">
                                <div class="col-auto">
                                    <div class="box-icon">
                                        <ion-icon name="archive"></ion-icon>
                                    </div>
                                </div>
                                <div class="col">
                                    <h3 class="box-title"> Kantor Cabang Semarang <hr style="border: 1px solid black;"></h3>
                                    <p class="box-desc">Perum Graha Taman Nirwana Blok C3-11 Banaran, Gunungpati, Semarang<br/><br/>
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>--}}
@stop