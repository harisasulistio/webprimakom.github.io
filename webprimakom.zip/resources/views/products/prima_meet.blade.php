@extends('layout2')
@section('content')
<style type="text/css">
    .section.section-grey {
    background: #ffffff;
}
</style>
<section class="section is-sm section-about">
    <div class="container">
        {{--<h2 class="section-title mt-5">Prima Meet<span class="text-primary">. </span></h2>--}}

        <div class="row flex vcenter pt-5 mt-5">
            <div class="col-lg-8" data-aos="fade-left" data-aos-delay="200">
				<div class="section-head">
					<h2 class="section-title">Prima Meet<span class="text-primary">. </span></h2>
				</div>
                <div class="section-body">
                    <p class="section-desc">Layanan Meeting melalui virtual yang diberikan secara gratis kepada pelanggan PT Prima Mandiri Komunikasi didalam upaya meningkatkan koordinasi dan efektif untuk menekan waktu koordinasi.</p>
                </div>
			</div>
			<div class="col-lg-4" data-aos="fade-left" data-aos-delay="300">
                <img class="about-img" src="{{URL::to('/assets_web/produk/primameet.png')}}" alt="">
            </div>
		</div>

		<div class="row flex vcenter justify-content-center pt-5 mt-5">
            <div class="col-12">
				<div class="section-head" data-aos="fade-up" data-aos-delay="200">
					<h2 class="section-title"> Keunggulan Prima Meet<span class="text-primary">. </span></h2>
				</div>
                {{--<div class="section-body">
                    <p class="section-desc">Layanan Meeting melalui virtual yang diberikan secara gratis kepada pelanggan PT Prima Mandiri Komunikasi didalam upaya meningkatkan koordinasi dan efektif untuk menekan waktu koordinasi.</p>
                </div>--}}
			</div>
			<div class="col-lg-8" data-aos="fade-up" data-aos-delay="300">
                <img class="about-img" src="{{URL::to('/assets_web/produk/keunggulan_primameet.jpg')}}" alt="">
            </div>
		</div>
    </div>
</section>

@stop