<h4 class="section-title" style="font-size:20px;">Project Team</h4>
  <br/>
  <br/>
    <div class="row">
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="Jane" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>Jane Doe</h2>
            <p class="title">CEO & Founder</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="Mike" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>Mike Ross</h2>
            <p class="title">Art Director</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="card">
          <img src="{{URL::to('assets_web/Foto/om_agus_bulat.png')}}" alt="John" style="width:100%;border-radius: 10px 10px 10px 10px;">
          <div class="container">
            <br/>
            <h2>John Doe</h2>
            <p class="title">Designer</p>
          </div>
        </div>
      </div>
    </div>